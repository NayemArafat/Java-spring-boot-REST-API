package com.ibcs.assessment.assessment.enums;

public enum GENDER {
  MALE,
  FEMALE,
  OTHERS

}
